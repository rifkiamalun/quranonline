/* Now we are write our js code here for making our digital clock so we can use it */

/* I here by make a function named as displayTime you can use any function name you like but for other's understanding use your functions name which is relavant to your task */
function displayTime(){
    var date = new Date();
    var hours = date.getHours(); //getHours is the method in js which give us the hours from 0-23
    var minutes = date.getMinutes(); //getMinutes is the method in js which give us the Minutes from 0-59
    var seconds = date.getSeconds(); //getSeconds is the method in js which give us the seconds from 0-59
    var session = "AM";
    
    if(hours==0){
      hours=12; //Here we compare if hours is equals to 0 it changes to hours is equal to 12
    }
    
    if(hours > 12){
      hours = hours - 12; // here if hours is greater than 12 then it assign the hours is     equal to hours - 12.
      //Let take an example if the hours is 18 so this statement does  hours = 18 - 12
      //that is 6. 
      session = "PM"; // it does 6 to 6 P.M
    }
    
    hours = (hours < 10) ? "0" + hours : hours; // here we can use ternary statement 
   // it means the conditions checked weather it is true or false.
    //if the condition is true the first statement will be follow.
    //if the condition is false the second statement will be follow. " : " this is the statement break if the condition is true  the //statement before this " : " will be followed else after statement will be followed. same wwe can do with minute or second statement
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;
    
    var time = hours + ":" + minutes + ":" + seconds + " " + session; //This statement follows the rule that how can we see the time like firts hours, then minutes, then seconds followed by : between them after it tells the time is in A.M or in P.M by using above conditions.
    
    document.getElementById("digitalClock").innerText = time; //getElementById tell the javascript that on which place in html code we have to use this code as we mentioned digitalClock in div elements in html so it is used there.
    document.getElementById("digitalClock").textContent = time;
    
    setTimeout(displayTime, 1000); //it changes our time after every 1000 here the 1000 is 1 seconds means 1000 milliseconds = 1 sec. it will change the clock time after every second which is actually we want.
    
  }
  
  displayTime();