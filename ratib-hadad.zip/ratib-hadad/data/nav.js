
//Nava Function 
function myFunction  () {
    $('#home').click(() => {
        document.location.href = 'index.html', '_blank';
        target(_blank);
    });
    $('#tawasul').click(() =>{
        document.location.href = "tawasul.html";

    });
    $('#jdwlSholat').click(() =>{
        document.location.href = 'sholat.html';
    });
    $('#daftar').click(() => {
        document.location.href = 'sejarah.html';
    });
  }

//Button Click Content 
  function visitPage(){
    window.location='tawasul.html';

}
function visitTawasul(){
    window.location='ratib-hadad.html'
}

function dzikir(){
    window.location='doa-list.html'
}

function maulidDiba(){
    window.location='maulid-diba.html'
}

function maulidSimtu(){
    window.location='maulid-simtuduror.html'
}



//Navbar Sticky On Page 



