

  //Fucntion Button Card 

 

  //
//End OF Nama Surat  

//DOa List 

const doaListPage = () => {
    //Doa-list.html
    const warna = [
        'list-group-item-primary',
        'list-group-item-secondary',
        'list-group-item-success',
        'list-group-item-danger',
        'list-group-item-warning'
    ];

    let i = 1;
    doa.forEach((d) => {
        const html = `<li id="${i}" class="doa list-group-item ${warna[d.warna-1]} mt-3">Do'a ${d.nama} </li>`;
        $('#doaH').append(html);
        i++;
    })

    $('.doa').click((e) => {
        document.location.href = `doa.html?${$(e.target).attr('id')}`;
    });




};

const doaPage = () => {
    //Doa.html
    const url = window.location.href;
    const id = url.substr(url.indexOf('?') + 1);

    d = doa[id - 1];

    $('.judul').text(`Do'a ${d.nama}`);
    $('.teks-arab').text(d.arab);
    $('.teks-latin').text(d.latin);
    $('.teks-indo').text(d.indo);
};


//Button Effect 
  
const words = ["DOWNLOAD"];
let i = 0;
let timer;

function typingEffect() {
	let word = words[i].split("");
	var loopTyping = function() {
		if (word.length > 0) {
			document.getElementById('word').innerHTML += word.shift();
		} else {
			deletingEffect();
			return false;
		};
		timer = setTimeout(loopTyping, 500);
	};
	loopTyping();
};

function deletingEffect() {
	let word = words[i].split("");
	var loopDeleting = function() {
		if (word.length > 0) {
			word.pop();
			document.getElementById('word').innerHTML = word.join("");
		} else {
			if (words.length > (i + 1)) {
				i++;
			} else {
				i = 0;
			};
			typingEffect();
			return false;
		};
		timer = setTimeout(loopDeleting, 200);
	};
	loopDeleting();
};

typingEffect();



//Registrasi Service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js').then(function(registration) {
      // Registration was successful
      console.log('ServiceWorker registration successful with scope: ', registration.scope);
    }, function(err) {
      // registration failed :(
      console.log('ServiceWorker registration failed: ', err);
    });
  });
}


