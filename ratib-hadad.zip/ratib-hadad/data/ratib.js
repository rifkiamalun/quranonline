const ratibBody = document.querySelector("#ratib-table > tbody");

function loadRatib () {
    const request = new XMLHttpRequest();

     request.open("GET", "data/ratib.json");

     request.onload = () => {
         try {
            const json = JSON.parse(request.responseText)
            populateRatib(json);
         }catch (e) {
             console.warn("Could not load ratib! :(");
                console.log(e);
         }
     };
     request.send();
    }

    function populateRatib (json){
        console.log(json);

        while (ratibBody.firstChild){
            ratibBody.removeChild(ratibBody.firstChild);
        }

        json.forEach((row) => {
            const tr = document.createElement("tr");



            row.forEach((cell) => {
                const td = document.createElement("td");
                td.textContent = cell;
                tr.appendChild(td);
            });
            ratibBody.appendChild(tr);
        });
    }

    document.addEventListener("DOMContentLoaded", () => { loadRatib(); });

